#include <gtk/gtk.h>


void on_buttonHello_clicked (GtkWidget *objet_graphique, gpointer user_data);
void sayHello( char nom[],char hello[]);

void
on_buttonconnecter_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_comboboxentry3_editing_done         (GtkCellEditable *celleditable,
                                        gpointer         user_data);
