void sayHello( char name[],char hello[]);

