#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

#include "greeting.h"
void on_buttonHello_clicked (GtkWidget *objet_graphique, gpointer user_data)

{
GtkWidget* input;
GtkWidget* output;
char Nom[10]; 
char Hello[10]; 
sayHello(Nom,Hello);
input = lookup_widget(objet_graphique, "entryNom") ;
output = lookup_widget(objet_graphique, "labelHello") ;
strcpy(Nom,gtk_entry_get_text(GTK_ENTRY(input)));
gtk_label_set_text(GTK_LABEL(output),Hello);

}

void
on_buttonconnecter_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_comboboxentry3_editing_done         (GtkCellEditable *celleditable,
                                        gpointer         user_data)
{

}

